package com.jpmc.poc.Constant;

public class CreditcardsUIConstants {
	
	/*
	 * Chase - Credit card screen Card finder image details
	 */
	
	public static final String creditCards_Screen_IMG_mobile =  "ctl00_Header_CClamp_Chase_Logo~ID";
	public static final String creditCards_Screen_IMG =  "//div[@class='home-banner']";
	public static final String creditCards_Screen1_IMG =  "//div[@class='home-banner']/div/a/img";
    public static final String creditCards_Screen_NameOf_Logo = "Credit Cards Screen";
    public static final String creditCards_Screen_IMG_Cooridinate = "409X70";
    public static final String creditCards_Screen_IMG_HeightWidth = "720X260";
    public static final String creditCards_Screen_IMG_Cooridinate_Mobile = "56X174";
    public static final String creditCards_Screen_IMG_HeightWidth_Mobile = "269X420";
    public static final String creditCards_Screen_IMG_Cooridinate_Tablet = "56X174";
    public static final String creditCards_Screen_IMG_HeightWidth_Tablet = "269X420";
    public static final String creditCards_Screen_loadingTime_Performance = "";
    public static final String creditCards_Screen_IMG_Accessibility = "New! Chase Freedom Unlimited.  Unlimited 1.5% cash back.  $150 bonus.  No Annual fee.  Learn More.";

}

