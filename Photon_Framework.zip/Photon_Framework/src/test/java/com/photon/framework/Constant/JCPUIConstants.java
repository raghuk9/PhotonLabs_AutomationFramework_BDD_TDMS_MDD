package com.photon.framework.Constant;

public class JCPUIConstants {
	

	public static final String userName_TXT =  "emailidLogin~ID";
	public static final String password_TXT =  "mypasswdLogin~ID";
	public static final String login_BTN =  "signIn~ID";
	public static final String my_Account_BTN = ".//*[@id='coldState']/ul/li[2]/a";
	public static final String Logout_BTN = ".//*[@id='logoutForm']/fieldset/p/a/span";
	public static final String Search_TXT = "searchTerm~ID";
	public static final String Search_BTN = "searchbutton~ID";
	public static final String Product_Select_BTN = ".//*[@id='pp5006950031']/div[3]/a[1]/div[1]";
	public static final String Size_Select_BTN = ".//*[@id='pp50069500315neck size']";
	public static final String Sleevesize_Select_BTN = ".//*[@id='pp50069500311sleeve']";
	public static final String AddTOBAG_BTN = "addtobagbopus~ID";
	public static final String CHECKOUT_POPUP_BTN = "btncheckout~ID";
	public static final String CHECKOUT_BTN = ".//*[@id='Checkout']";
	public static final String POPUP_BTN ="closeButton~ID";
	public static final String Menu_01 = ".//*[@id='topmenu']/li[1]/a";
	public static final String Menu_02 = ".//*[@id='topmenu']/li[2]/a";
	public static final String Menu_03 = ".//*[@id='topmenu']/li[3]/a";
	public static final String Menu_04 = ".//*[@id='topmenu']/li[4]/a";
	public static final String Menu_05 = ".//*[@id='topmenu']/li[5]/a";
	public static final String Menu_06 = ".//*[@id='topmenu']/li[6]/a";

	public static final String userName_TXT_mobile = "";
	public static final String password_TXT_mobile = "";
	
	
}
