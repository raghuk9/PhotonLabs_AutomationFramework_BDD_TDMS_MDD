package com.photon.framework.Constant;

public class JCP_LogIn_UIConstantsSE {

	public static final String userName_TXT_SE =  "emailidLogin~ID";
	public static final String password_TXT_SE =  "mypasswdLogin~ID";
	public static final String login_BTN_SE =  "signIn~ID";
	public static final String Logout_BTN_SE = ".//*[@id='logoutForm']/fieldset/p/a/span";
	
}
