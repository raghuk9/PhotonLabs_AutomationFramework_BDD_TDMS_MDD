package com.photon.framework.Constant;

public class JCP_MegamenuConstants {
	public static final String Menu_1 = ".//*[@id='topmenu']/li[1]/a";
	public static final String Menu_2 = ".//*[@id='topmenu']/li[2]/a";
	public static final String Menu_3 = ".//*[@id='topmenu']/li[3]/a";
	public static final String Menu_4 = ".//*[@id='topmenu']/li[4]/a";

}
