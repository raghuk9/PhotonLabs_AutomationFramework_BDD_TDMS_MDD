package com.photon.framework.Constant;

public class JCP_Search_Constants {
	
	//Desktop
	public static final String Search_TXT = "searchTerm~ID";

	//Mobile
	public static final String mobile_Search_BTN =".//*[@id='small-search-field']";
	
	//Native Application Android
	public static final String NAA_mobile_Search_TXT =".//*[@id='small-search-field']";
	

}
